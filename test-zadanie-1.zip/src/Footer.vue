<template>
    <footer class="footer">
        <div class="footer__container">
            <p>all rights reserved</p>
        </div>
    </footer>
</template>

<script>
export default {

}
</script>

<style scoped>
.footer__container {
    display: flex;
    margin-top: 30px;
    align-items: center;
    justify-content: center;
    width: 100%;
    background: #FAFAFA;
    padding: 10px 20px;
    font-family: 'Montserrat', sans-serif;
}
</style>