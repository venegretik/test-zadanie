import CustomButton from './CustomButton.vue'
import CustomInput from './CustomInput.vue'
export default [
    CustomButton,
    CustomInput
]