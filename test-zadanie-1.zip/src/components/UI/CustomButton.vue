<template>
    <button>
        <slot></slot>
    </button>
</template>

<script>
export default {
    name:'custom-button'
}
</script>

<style></style>